# xv6

Modifications to [xv6]for Lab assignments of Operating Systems course at University of Tehran

## Group Members:

1. kimia fakhari
2. Negar ghaderi
3. Mohammad Hossein Ataie


# OS_LAB4
