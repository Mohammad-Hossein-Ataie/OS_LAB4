#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"
#include "condvar.h"
#include <math.h>
#include <limits.h>
// 0 --> reader
// 1 --> writer
unsigned int int_to_bin(unsigned int k) {
    return (k == 0 || k == 1 ? k : ((k % 2) + 10 * int_to_bin(k / 2)));
}
int mst(int num)
{
    long z;
    long tmp = num;

    for(z = 10; z < INT_MAX; z *= 10) 
    {
        if( !(num / z)) break;
    }
    return (tmp % (z / 10));
}

#define READER 0
#define WRITER 1

int
main(int argc, char *argv[])
{
  unsigned int decimal = atoi(argv[1]);
	if(argc < 2)
    {
		printf(2, "You Must Enter One Number!\n");
		exit();
	}
    unsigned int binary = int_to_bin(decimal);
    int c = 0; /* digit position */
    int n = binary;
    while (n != 0)
    {
        n /= 10;
        c++;
    }
    int numberArray[c];
    c = 0;    
    n = binary;
    /* extract each digit */
    while (n != 0)
    {
        numberArray[c] = n % 10;
        n /= 10;
        c++;
    }
    if(argc == 2)
    {
        int numOfones = 0;
        int numOfzeros = 0;
        for(int i = 0; i < c-1; i++)
        {
            if (numberArray[i] == 0) numOfzeros++;
            else if(numberArray[i] == 1) numOfones++;
        }
        printf(1,"num of ones is: %d\n",numOfones);
        printf(1,"num of zeros is: %d\n",numOfzeros);
        if (fork() == 0) {
          for (int i = 0; i < numOfones; i++) {
            if (fork() == 0) {
              rwtest(WRITER);
              exit();
            }
          }
        }
        else if (fork() == 0) {
          for (int i = 0; i < numOfzeros; i++) {
            if (fork() == 0) {
              rwtest(READER);
              exit();
            }
          }
        }

        while(wait() > -1);
    }

  exit();
}